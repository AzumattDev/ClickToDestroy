| `Version` | `Update Notes`      |
|-----------|---------------------|
| 1.0.1     | - Update for 0.5.12 |
| 1.0.0     | - Initial Release   |